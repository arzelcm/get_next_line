#include "../get_next_line.h"
#include <unistd.h>
#include <fcntl.h>

void	ft_putstr_fd(char *s, int fd)
{
	if (!s || fd < 0)
		return ;
	while (*s != '\0')
	{
		write(fd, s, 1);
		s++;
	}
}

int	main(void)
{
	char *auxline;
	int	fd = open("test.txt", O_RDONLY);
	char *line = get_next_line(fd);
	while (line)
	{
		ft_putstr_fd(line, 1);
		auxline = get_next_line(fd);
		free(line);
		line = auxline;
	}
	if (line)
		free(line);
	close(fd);
	return (0);
}
